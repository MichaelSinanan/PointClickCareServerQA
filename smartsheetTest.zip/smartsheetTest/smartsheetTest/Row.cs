﻿using System.Collections.Generic;


namespace smartsheetTest
{
    public class Row
    {
        public List<string> ssTitle;
        public string htmlTitle;
        public List<string> ssRoles;
        public List<string> htmlRoles;
        public List<string> ssRowId;
        public List<string> htmlfileLoc;
        public List<string> htmlfilename;


        public Row()
        {



        }



        public Row(List<string> sstitle, List<string> ssroles)
        {
            this.ssTitle = sstitle;
            this.ssRoles = ssroles;
        
        }

        public Row(string htmltitle, List<string> htmlroles, List<string> htmlfileloc, List<string> htmlname, char typeIndicator) //char passed to specify different constructor arguments -- all HTML rows must pass a char value 
        {
            this.htmlTitle = htmltitle;
            this.htmlRoles = htmlroles;
            this.htmlfileLoc = htmlfileloc;
            this.htmlfilename = htmlname;
        }
    }
}