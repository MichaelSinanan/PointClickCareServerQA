﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.IO;

using System.Threading;
using Microsoft.VisualBasic.FileIO;
using CsvHelper;
using smartsheetTest;

class Program
    {
    private static string output;

    static void Main(string[] args)
        {
            try
            {
            //beginning of ss extraction code


            //my access token
            //should be parameter
                string token = "2078bme83q0mi7rvcv2m93ten2";

                //URL with ID of sheet in question
                //should be parameter

                //default values
                String baseURL = "https://api.smartsheet.com/2.0/sheets/";
                String sheetID = "3482488099104644";  //3482488099104644
                                                      //3295724667463556
                String filePath = null;
                String filename = null;
                String stripTrailingComma = null;

              
            
                //Build a HttpWebRequest with the URL
                HttpWebRequest getRequest = WebRequest.Create(baseURL + sheetID) as HttpWebRequest;

                //set the filetypes and headers
                getRequest.ContentType = "application/json; charset=utf-8";

                getRequest.Method = "GET";

                //this must be set to authorize the URL call
                getRequest.Headers.Add("Authorization: Bearer " + token);

                //this line forces the output to a CSV - this is required to get the cleaned-up file contents  
                getRequest.Accept = "text/csv";

                //make the request
                Stream dataStream = getRequest.GetResponse().GetResponseStream();

                //read the response
                StreamReader objReader = new StreamReader(dataStream);
                string output = objReader.ReadToEnd();

            //end  of ss extraction code


            
            //store SS values in build -- list of list of string arrays
            //ss values accessible easily
            List<List<string[]>> build = new List<List<string[]>>();
            List<string[]> tempArr;
            List<string> temprole;
            List<string> tempssTtl;

            string[] lines = output.Split(new string[] { "\r\n", "\n" }, StringSplitOptions.None);
            foreach (string s in lines)
            {
                
                string[] str =  s.Split(',');
             
                tempArr = new List<string[]>();
                tempArr.Add(str);
                build.Add(tempArr);
            }

       
       //find collumn containing Course and Wiki
       //REQUIRED TO RUN PROGRAM
            int counter = 0;

            int colNum = build[0][0].Length;

            int coursewikicount = 0;
            foreach (string s in build[0][0])
            {
                if ((s.Contains("Course and Wiki"))||(s.Contains("Course and Content"))){
                    break;
                }
                coursewikicount++;
            }

            //take contents from list of strings and produce List of Row objects
            //contains smartsheet title, and Role (indicated by index of occupied collumn)
            List<Row> lsRow = new List<Row>();
            foreach (List<string[]> lst in build)
            {
                foreach (string[] item in lst)
                {
                    int roleget = coursewikicount;
                    if (item.Length >= colNum)
                    {
                        temprole = new List<string>();
                        tempssTtl = new List<string>();
 
                        tempssTtl.Add(build[counter][0][coursewikicount]);
                        foreach (string strngprnt in item)
                        {
                            roleget++;
                           
                            if (((strngprnt.Contains("true")&& (roleget > coursewikicount))))
                            {
                                temprole.Add(roleget.ToString());
                                
                                lsRow.Add(new Row(tempssTtl, temprole));
                            }
                            
                        }
                        
                    }
                                    counter++;
                }

            }

            //remove duplicates
            string tempTitle = "";
            int rowcount = 0;
            foreach (Row ro in lsRow.ToList())
            {
                if (ro.ssTitle[0]==tempTitle)
                {
                    lsRow.Remove(ro);
                }
                tempTitle = ro.ssTitle[0];
                rowcount++;
            }


            //fill in smartsheet Role values -- replace index with role name
            int rolecount = 0;
          foreach (Row r in lsRow.ToList())
            {
                foreach (string srg in r.ssRoles.ToList())
                {
                    int indx = Int32.Parse(srg);
                    indx = indx - 4;
                    if ((indx>0)&&(indx<build[0][0].Length)) {
                      
                        r.ssRoles[rolecount] = build[0][0][indx];
                    }
                    rolecount++;
                }
                rolecount = 0;
            }

            

          foreach (Row r in lsRow.ToList())
            {
                Console.WriteLine(r.ssTitle[0]);

                foreach (string s in r.ssRoles)
                {
                    Console.WriteLine(s);
                }

            }

         
                


            //need to strip trailing column seperators from each non-header row
            //shows up as ,<LF>
            //we look for LF and then check if previous character is a comma. If it is, remove from string



            //write the file output
            //this should probably be a parameter







        }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        Console.ReadLine();


       
    }
    }


